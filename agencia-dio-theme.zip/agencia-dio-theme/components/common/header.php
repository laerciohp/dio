<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<header class="Header">
  <section class="Header__content">
    <a href="<?php bloginfo( 'url' ); ?>" class="Header__content--logo">
      <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/logo-dio-white.png" alt="">
    </a>

    <?php if ( is_front_page() ): ?>
    <nav class="Header__content--nav" id="menu">
      <ul>
        <li data-menuanchor="sobre"><a href="#2" class="menu-link">Sobre</a></li>
        <li data-menuanchor="clientes"><a href="#6" class="menu-link">Clientes</a></li>
        <li data-menuanchor="portfolio"><a href="#7" class="menu-link">Portfólio</a></li>
        <li data-menuanchor="servicos"><a href="#8" class="menu-link">Serviços</a></li>
        <li data-menuanchor="googlepartner"><a href="#9" class="menu-link">Google Partner</a></li>
        <li data-menuanchor="insights"><a href="#insights" class="menu-link">Insights</a></li>
        <li data-menuanchor="contato"><a href="#11" class="menu-link">Contato</a></li>
      </ul>
    </nav>
    <?php else: ?>
    <nav class="Header__content--nav">
      <ul>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-sobre" class="">Sobre</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-clientes" class="">Clientes</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-portfolio" class="">Portfólio</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-servicos" class="">Serviços</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-google" class="">Google Partner</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-insights" class="">Insights</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-contato" class="">Contato</a></li>
      </ul>
    </nav>
    <?php endif; ?>

    <button class="Header__content--menu">
      <svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m11 16.745c0-.414.336-.75.75-.75h9.5c.414 0 .75.336.75.75s-.336.75-.75.75h-9.5c-.414 0-.75-.336-.75-.75zm-9-5c0-.414.336-.75.75-.75h18.5c.414 0 .75.336.75.75s-.336.75-.75.75h-18.5c-.414 0-.75-.336-.75-.75zm4-5c0-.414.336-.75.75-.75h14.5c.414 0 .75.336.75.75s-.336.75-.75.75h-14.5c-.414 0-.75-.336-.75-.75z" fill-rule="nonzero"/></svg>
    </button>

    <button class="Header__content--close">
      <svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m12 10.93 5.719-5.72c.146-.146.339-.219.531-.219.404 0 .75.324.75.749 0 .193-.073.385-.219.532l-5.72 5.719 5.719 5.719c.147.147.22.339.22.531 0 .427-.349.75-.75.75-.192 0-.385-.073-.531-.219l-5.719-5.719-5.719 5.719c-.146.146-.339.219-.531.219-.401 0-.75-.323-.75-.75 0-.192.073-.384.22-.531l5.719-5.719-5.72-5.719c-.146-.147-.219-.339-.219-.532 0-.425.346-.749.75-.749.192 0 .385.073.531.219z"/></svg>
    </button>

  </section>

  <nav class="Header__mobile">
    <?php if ( is_front_page() ): ?>
      <ul>
        <li><a href="#secao-sobre" class="linkMobileHome">Sobre</a></li>
        <li><a href="#secao-clientes" class="linkMobileHome">Clientes</a></li>
        <li><a href="#secao-portfolio" class="linkMobileHome">Portfólio</a></li>
        <li><a href="#secao-servicos" class="linkMobileHome">Serviços</a></li>
        <li><a href="#secao-google" class="linkMobileHome">Google Partner</a></li>
        <li><a href="#secao-insights" class="linkMobileHome">Insights</a></li>
        <li><a href="#secao-contato" class="linkMobileHome">Contato</a></li>
      </ul>
    <?php endif; ?>

    <?php if ( !is_front_page() ): ?>
      <ul>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-sobre" class="linkMobile">Sobre</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-clientes" class="linkMobile">Clientes</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-portfolio" class="linkMobile">Portfólio</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-servicos" class="linkMobile">Serviços</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-google" class="linkMobile">Google Partner</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-insights" class="linkMobile">Insights</a></li>
        <li><a href="<?php bloginfo( 'url' ); ?>#secao-contato" class="linkMobile">Contato</a></li>
      </ul>
    <?php endif; ?>
  </div>
</header>