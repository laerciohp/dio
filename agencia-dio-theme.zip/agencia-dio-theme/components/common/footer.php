<?php if ( ! function_exists( 'add_action' ) ) exit; ?>

<div class="section" data-anchor="contato">
<div id="secao-contato"></div>
<div class="FooterHeight">
  <?php require_once  get_template_directory() . '/components/home/contact.php'; ?>
  <footer class="Footer">
    <section class="container container--full">
      <section class="Footer__content">
  
        <section class="Footer__content--about">
          <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/logo-dio-orange.png" alt="DIO" class="logo">
          <?php the_field( 'endereco', 'option' ); ?>
        </section>
  
        <nav class="Footer__content--links">
          <ul>
            <li>
              <a href="#">Sobre</a>
            </li>
            <li>
              <a href="#">Google Partner</a>
            </li>
            <li>
              <a href="#">Clientes</a>
            </li>
            <li>
              <a href="#">Insights</a>
            </li>
            <li>
              <a href="#">Portfólio</a>
            </li>
            <li>
              <a href="#">Contato</a>
            </li>
            <li>
              <a href="#">Serviços</a>
            </li>
          </ul>
        </nav>
  
        <section class="Footer__content--contacts">
          <nav class="social">
            <ul>
              <?php if ( get_field( 'tiktok', 'option' ) ): ?>
              <li>
                <a href="<?php the_field( 'tiktok', 'option' ); ?>" target="_blank">
                  <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-tiktok.png" alt="">
                </a>
              </li>
              <?php endif; ?>

              <?php if ( get_field( 'linkedin', 'option' ) ): ?>
              <li>
                <a href="<?php the_field( 'linkedin', 'option' ); ?>" target="_blank">
                  <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-linkedin.png" alt="">
                </a>
              </li>
              <?php endif; ?>

              <?php if ( get_field( 'instagram', 'option' ) ): ?>
              <li>
                <a href="<?php the_field( 'instagram', 'option' ); ?>" target="_blank">
                  <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-instagram.png" alt="">
                </a>
              </li>
              <?php endif; ?>

              <?php if ( get_field( 'facebook', 'option' ) ): ?>
              <li>
                <a href="<?php the_field( 'facebook', 'option' ); ?>" target="_blank">
                  <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-facebook.png" alt="">
                </a>
              </li>
              <?php endif; ?>
            </ul>
          </nav>
  
          <span>Telefone</span>
          <p><?php the_field( 'telefone', 'option' ); ?></p>
          <span>Email</span>
          <p><a href="mailto:<?php the_field( 'email', 'option' ); ?>" target="_blank"><?php the_field( 'email', 'option' ); ?></a></p>
        </section>
  
      </section>
    </section>
  </footer>
</div>


</div>