<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<div class="section" data-anchor="portfolio">
<div id="secao-portfolio"></div>
<section class="Home__Portfolio">
  <section class="container container--full">
    <h4 class="Home__Portfolio--title">
      Portfólio
    </h4>
  </section>
  
  <section class="swiper Home__Portfolio--slider">

    <?php
      if( have_rows( 'portfolio' ) ):
        while( have_rows( 'portfolio' ) ): the_row();
    ?>
      <div class="swiper-wrapper">
      <?php
        $featured_posts = get_sub_field( 'listagem' );
        if( $featured_posts ):
          $i = 0;
          foreach( $featured_posts as $post ):
          setup_postdata($post);
          $i++;
      ?>
      
          <?php
            if( have_rows( 'informacoes_do_card' ) ):
              while( have_rows( 'informacoes_do_card' ) ): the_row();
          ?>
          <div class="swiper-slide">

            <a href="<?php the_permalink(); ?>" class="item">
        
              <div class="crop">
                <div class="overlay"></div>
                <div class="image" style="background-image:url(<?php the_sub_field( 'imagem' ); ?>)"></div>
              </div>
          
              <div class="text">
                <h2 class="text__title">
                  <?php the_sub_field( 'resumo' ); ?>
                </h2>
        
                <div class="text__description">
                  <p><?php the_title(); ?></p>
                  <span>Branding / Web Design / UI | UX</span>
                </div>
              </div>
          
            </a>
          </div>
          <?php
              endwhile;
            endif;
          ?>
        
        <?php
          endforeach;
          wp_reset_postdata();
        endif;
        ?>
      </div>

      <div class="navSlider">
        <div class="scroll">
          <div class="swiper-pagination"></div>
        </div>
        <div class="buttons">
          <button class="navSlider__prev"></button>
          <span class="count"><span id="slide-ativo">1</span> / <?php echo $i; ?></span>
          <button class="navSlider__next"></button>
        </div>
      </div>

    <?php
        endwhile;
      endif;
    ?>
    
  </section>

  <div class="Home__Portfolio--all wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
    <a href="<?php bloginfo( 'url' ); ?>/portfolio">
      Conheça todos os projetos &gt;&gt;&gt;
    </a>
  </div>
</section>

</div>