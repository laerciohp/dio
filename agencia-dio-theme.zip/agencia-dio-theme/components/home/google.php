<?php if ( ! function_exists( 'add_action' ) ) exit; ?>

<?php
  if( have_rows( 'selos' ) ):
    while( have_rows( 'selos' ) ): the_row();
?>
<div class="section" data-anchor="googlepartner">
<div id="secao-google"></div>
<section class="Home__Google">
  <section class="container container--full">
    <h4 class="Home__Google--title">
      Google Partners
    </h4>

    <p class="Home__Google--description wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
      <?php the_sub_field( 'titulo' ); ?>
    </p>

    <section class="Home__Google--list wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
      <?php
        if( have_rows( 'imagens' ) ):
          while( have_rows( 'imagens' ) ): the_row();
      ?>
        <img src="<?php the_sub_field( 'logo' ); ?>" alt="">
      <?php
          endwhile;
        endif;
      ?>
    </section>
    
  </section>
</section>

</div>
<?php
    endwhile;
  endif;
?>