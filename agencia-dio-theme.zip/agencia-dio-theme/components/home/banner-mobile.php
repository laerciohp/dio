<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<?php
  if( have_rows( 'banner' ) ):
    while( have_rows( 'banner' ) ): the_row();
?>
<section class="Home__BannerMobile">
  <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/logo-dio-big-black.png" alt="" class="logo">

  <div class="title">
    <?php the_sub_field( 'primeira_frase' ); ?>
  </div>

  <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/banner/circle-1.png" alt="" class="circles__1">
</section>
<?php
    endwhile;
  endif;
?>