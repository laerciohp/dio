<?php if ( ! function_exists( 'add_action' ) ) exit; ?>

<?php
  if( have_rows( 'servicos' ) ):
    while( have_rows( 'servicos' ) ): the_row();
?>

<div class="section" data-anchor="servicos">
  <div id="secao-servicos"></div>
  <section class="Home__Services">
    <section class="container container--full">
      <h4 class="Home__Services--title">
        O que fazemos
      </h4>

      <div class="Home__Services--content desktop">
        <div class="nav wow fadeIn" data-wow-duration=".9s" data-wow-delay="1s">

          <?php
            if( have_rows( 'listagem' ) ):
              $i = 0;
              while( have_rows( 'listagem' ) ): the_row();
              $i++;
          ?>
          <button class="nav__button <?php echo $i == 1 ? 'active' : ''; ?>" data-service="<?php echo $i; ?>">
            <span class="number">0<?php echo $i; ?></span>
            <span class="text">
            <?php the_sub_field( 'titulo' ); ?>
            </span>
          </button>
          <?php
              endwhile;
            endif;
          ?>

          
        </div>

        <div class="text wow fadeIn" data-wow-duration=".9s" data-wow-delay="1s">
          <div class="line">

            <?php
              if( have_rows( 'listagem' ) ):
                $i = 0;
                while( have_rows( 'listagem' ) ): the_row();
                $i++;
            ?>
            <div class="line__item item<?php echo $i; ?> <?php echo $i == 1 ? 'active' : ''; ?>">
              0<?php echo $i; ?>
            </div>
            <?php
                endwhile;
              endif;
            ?>
          </div>

          <?php
            if( have_rows( 'listagem' ) ):
              $i = 0;
              while( have_rows( 'listagem' ) ): the_row();
              $i++;
          ?>

          <div class="content content<?php echo $i; ?> <?php echo $i == 1 ? 'active' : ''; ?>">
            <?php the_sub_field( 'descricao' ); ?>
          </div>
          <?php
              endwhile;
            endif;
          ?>

        </div>
      </div>

      <div class="Home__Services--content mobile">
        <?php
          if( have_rows( 'listagem' ) ):
            $i = 0;
            while( have_rows( 'listagem' ) ): the_row();
            $i++;
        ?>
        <div class="BoxMobile">
          <h3>
            <span class="number">0<?php echo $i; ?></span>
            <span class="text">
              <?php the_sub_field( 'titulo' ); ?>
            </span>
          </h3>

          <div class="content">
            <?php the_sub_field( 'descricao' ); ?>
          </div>
        </div>
        <?php
            endwhile;
          endif;
        ?>

        
      </div>
      
    </section>
  </section>

</div>

<?php
    endwhile;
  endif;
?>