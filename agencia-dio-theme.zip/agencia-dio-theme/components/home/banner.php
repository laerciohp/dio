<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<?php
  if( have_rows( 'banner' ) ):
    while( have_rows( 'banner' ) ): the_row();
?>

<div class="section" data-anchor="inicio">
  <section class="Home__Banner">
    <section class="fullHeight">
      <section class="Home__Banner--content">
        <section class="text">
          <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/logo-dio-big-black.png" alt="" class="text__logo">
          <div class="text__title">
            <?php the_sub_field( 'primeira_frase' ); ?>
          </div>
          <div class="text__description">
            <?php the_sub_field( 'segunda_frase' ); ?>
          </div>
        </section>
      </section>
    </section>
  
    <div class="circles">
      <div class="circles__center">
        <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/banner/circle-center.png" alt="" class="">
      </div>
  
      <div class="circles__one">
        <div class="overlay"></div>
        <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/banner/circle-1.png" alt="" class="circles__one--image">
      </div>
      <div class="circles__two">
        <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/banner/circle-2.png" alt="" class="circles__two--image">
      </div>
  
      <div class="circles__three">
        <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/banner/circle-3.png" alt="" class="circles__three--image">
      </div>
    </div>
  
    <div class="share">
      <span>Nos siga!</span>
  
      <img src="<?php bloginfo( 'template_url' ); ?>/assets/images/arrow-banner.png" alt="">
  
      <nav>
        <ul>
          <?php if ( get_field( 'tiktok', 'option' ) ): ?>
          <li>
            <a href="<?php the_field( 'tiktok', 'option' ); ?>" target="_blank"><img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-tiktok-gray.png" alt=""></a>
          </li>
          <?php endif; ?>
          
          <?php if ( get_field( 'instagram', 'option' ) ): ?>
          <li>
            <a href="<?php the_field( 'instagram', 'option' ); ?>" target="_blank"><img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-instagram-gray.png" alt=""></a>
          </li>
          <?php endif; ?>
          
          <?php if ( get_field( 'linkedin', 'option' ) ): ?>
          <li>
            <a href="<?php the_field( 'linkedin', 'option' ); ?>" target="_blank"><img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-linkedin-gray.png" alt=""></a>
          </li>
          <?php endif; ?>
          
          <?php if ( get_field( 'facebook', 'option' ) ): ?>
          <li>
            <a href="<?php the_field( 'facebook', 'option' ); ?>" target="_blank"><img src="<?php bloginfo( 'template_url' ); ?>/assets/images/icon-facebook-gray.png" alt=""></a>
          </li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
  
    <div class="pulse">Seu próximo passo, aqui</div>
  </section>
</div>
<?php
    endwhile;
  endif;
?>