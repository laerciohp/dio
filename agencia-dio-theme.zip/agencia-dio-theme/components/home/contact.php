<?php if ( ! function_exists( 'add_action' ) ) exit; ?>



<section class="Home__Contact">
  <section class="container container--full">
    <h4 class="Home__Contact--title">
      Contato
    </h4>
    <section class="Home__Contact--content">
      <section class="text wow fadeIn" data-wow-duration=".9s" data-wow-delay="1s">
        <p>
          Queremos ouvir você – deixe sua mensagem.
        </p>
      </section>

      <section class="form wow fadeIn" data-wow-duration=".9s" data-wow-delay="1s">
        <?php echo do_shortcode( '[contact-form-7 id="904f258" title="Contato"]' ); ?>
      </section>
    </section>
  </section>
</section>