<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<?php
  if( have_rows( 'resultados' ) ):
    while( have_rows( 'resultados' ) ): the_row();
?>
<div class="section" data-anchor="sobre">
  <div id="secao-sobre"></div>
  <section class="Home__Results">
    <section class="container fullHeight">
      <section class="Home__Results--content">

        <?php
          if( have_rows( 'listagem' ) ):
            while( have_rows( 'listagem' ) ): the_row();
        ?>

        <div class="block">
          <div class="block__header wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
            <div class="block__header--value">
              <p><?php the_sub_field( 'valor' ); ?></p>
            </div>
  
            <div class="block__header--description">
              <?php the_sub_field( 'legenda' ); ?>
            </div>
          </div>
  
          <div class="block__divisor wow fadeInLeft" data-wow-duration=".9s" data-wow-delay="1s"></div>
  
          <div class="block__text wow fadeInDown" data-wow-duration=".9s" data-wow-delay="1s">
            <?php the_sub_field( 'descricao' ); ?>
          </div>
        </div>

        <?php
            endwhile;
          endif;
        ?>

      </section>
    </section>
  </section>
</div>
<?php
    endwhile;
  endif;
?>