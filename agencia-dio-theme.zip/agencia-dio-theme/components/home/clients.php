<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<div class="section" data-anchor="clientes">
  <div id="secao-clientes"></div>
  <section class="Home__Clients">
    <section class="container container--full">
      <h3 class="Home__Clients--title">Clientes</h3>

      <section class="Home__Clients--list wow fadeIn" data-wow-duration=".9s" data-wow-delay="1s">
        
        
        <?php 
$images = get_field('clientes');
$size = 'full'; // (thumbnail, medium, large, full or custom size)
if( $images ): ?>
    
        <?php foreach( $images as $image_id ): ?>
          <div class="item"><img src="<?php echo $image_id['url']; ?>" alt=""></div>
                
            
        <?php endforeach; ?>
    
<?php endif; ?>
      </section>
    </section>
  </section>
</div>