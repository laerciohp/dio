<?php if ( ! function_exists( 'add_action' ) ) exit; ?>

<?php
  if( have_rows( 'sobre' ) ):
    while( have_rows( 'sobre' ) ): the_row();
?>
<div class="section" data-anchor="pergunta">
  <section class="Home__Question">
    <div class="text wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
      <?php the_sub_field( 'primeira_secao' ); ?>
    </div>
  </section>
</div>

<div class="section" data-anchor="digital">
  <section class="Home__Question two">
    <div class="text wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
      <?php the_sub_field( 'segunda_secao' ); ?>
    </div>
  </section>
</div>

<div class="section" data-anchor="evoluimos">
  <section class="Home__Question three">
    <div class="text wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
      <?php the_sub_field( 'terceira_secao' ); ?>
    </div>
  </section>
</div>
<?php
    endwhile;
  endif;
?>