<?php if ( ! function_exists( 'add_action' ) ) exit; ?>

<div class="section">

<section class="Home__Blog" id="insights">
  <section class="container container--full">
    <h4 class="Home__Blog--title">
      Blog insights
    </h4>

    <div class="Home__Blog--description wow fadeIn" data-wow-duration=".9s" data-wow-delay="1s">
      <?php the_content(); ?>
    </div>


    <?php
      $args = new WP_Query( array(
        'post_type'      => 'post',
        'paged'          => $paged,
        'posts_per_page' => -1,
      ));

      $the_query = new WP_Query( $args );
    ?>

    <div class="Home__Blog--list wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1s">
      <?php
        if ( $the_query->have_posts() ):
          while ( $the_query->have_posts() ):
            $the_query->the_post();
            
            $permalink = get_permalink( get_the_ID() );
            $title = get_the_title();
            $thumb = get_the_post_thumbnail_url( get_the_ID() ,'full' );
      ?>

        <a href="<?php echo esc_url( $permalink ); ?>" class="Post">
          <div class="crop">
            <div class="thumb" style="background-image:url(<?php echo $thumb; ?>)"></div>
          </div>

          <div class="text">

            <h2 class="title">
              <?php echo esc_html( $title ); ?>
            </h2>
            <div class="excepert">
              <?php the_excerpt(); ?>
            </div>
          </div>
        </a>

      <?php
          endwhile;
        endif;
        wp_reset_postdata();
      ?>
    </div>
    
  </section>
</section>

</div>