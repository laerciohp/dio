<?php
  if ( ! function_exists( 'add_action' ) ) exit;
  require_once  get_template_directory() . '/template-home.php';