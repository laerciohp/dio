$(function(){

  var wow = new WOW( {
    mobile: false,
  });

  wow.init();

  $(window).on("scroll", function() {
    var y = $(this).scrollTop();
    if (y > 100) {
      $('.Header').addClass('fixed');
    } else {
      $('.Header').removeClass('fixed');
    }
  });

  $('.Header__content--menu').on('click', function() {
    $('.Header__mobile').addClass('show');
    $(this).hide();
    $('.Header__content--close').show();
    $('html, body').css('overflowY', 'hidden');
  });

  $('.Header__content--close').on('click', function() {
    $('.Header__mobile').removeClass('show');
    $(this).hide();
    $('.Header__content--menu').show();
    $('html, body').css('overflowY', 'auto');
  })

  $('.linkMobileHome').on('click', function() {
    $('html, body').css('overflowY', 'auto');
    $('.Header__content--close').hide();
    $('.Header__content--menu').show();
    $('.Header__mobile').removeClass('show');

    var href = $(this).attr('href'); 
    var targetOffset = $(href).offset().top;
    $('html, body').animate({ scrollTop: targetOffset }, 500);
  });

  function initFullPage() {
    $('#fullpage').fullpage({
      autoScrolling: true,
      scrollOverflow: true,
      navigation: false,
      scrollBar: true,
      scrollingSpeed: 300,
      fitToSection: true,
      touchSensitivity: 15,
      menu: "#menu",
      anchors: ['inicio', 'sobre', 'pergunta', 'digital', 'evoluimos', 'clientes', 'portfolio', 'servicos', 'googlepartner', 'insights', 'contato'],
    });
  }

  $(document).ready(function() {
    if ($(window).width() >= 768) {
      initFullPage();
    }
  });

  $(window).on('resize', function() {
    if ($(window).width() >= 768 && !$.fn.fullpage.destroy) {
      initFullPage();
    } else if ($(window).width() < 768 && $.fn.fullpage.destroy) {
      $.fn.fullpage.destroy('all');
    }
  });

  $('.wpcf7-submit').each(function() {
      var $originalButton = $(this);
      var buttonText = $originalButton.val();
      var buttonClasses = $originalButton.attr('class');
      var buttonId = $originalButton.attr('id');

      var newButton = $('<button type="submit"></button>')
          .addClass(buttonClasses)
          .attr('id', buttonId)
          .html('<span class="my-button-icon"></span> ' + buttonText);

      $originalButton.replaceWith(newButton);
  });

  $('.nav__button').on('click', function() {
    $('.nav__button').removeClass('active');
    $(this).addClass('active');
    var info = $(this).data('service');

    $('.line__item').removeClass('active');
    $('.item'+info).addClass('active');

    $('.content').removeClass('active');
    $('.content'+info).addClass('active');
  })

  

    const slider = new Swiper(".Home__Portfolio--slider", {
      direction: "horizontal",
      slidesPerView: 1,
      spaceBetween: 0,
      autoplay: {
        delay: 6000,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: ".navSlider__next",
        prevEl: ".navSlider__prev",
      },
      pagination: {
        el: ".swiper-pagination",
        type: "progressbar",
      },
      on: {
      slideChange: function () {
        document.getElementById('slide-ativo').textContent = this.activeIndex + 1;
      },
    },
    });
    
    document.getElementById('slide-ativo').textContent = slider.activeIndex + 1;
  




}, false );