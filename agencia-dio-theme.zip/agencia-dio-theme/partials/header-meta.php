<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?php bloginfo('name'); ?> - <?php the_title(); ?></title>
<!-- <link rel="shortcut icon" href="<?php //echo get_stylesheet_directory_uri()?>/assets/images/favicon/favicon.ico" />
<link rel="icon" type="image/png" sizes="32x32" href="<?php //echo get_stylesheet_directory_uri()?>/assets/images/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php //echo get_stylesheet_directory_uri()?>/assets/images/favicon/favicon-16x16.png"> -->


<script type="text/javascript">
  var templateUrl = '<?= get_bloginfo("url"); ?>';
</script>