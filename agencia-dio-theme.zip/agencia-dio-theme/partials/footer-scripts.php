<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<?php wp_footer(); ?>
