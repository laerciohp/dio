<?php
  if ( ! function_exists( 'add_action' ) ) exit;

  get_header();
?>

<?php
  get_footer();
?>