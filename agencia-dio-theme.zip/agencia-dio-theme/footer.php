<?php if ( ! function_exists( 'add_action' ) ) exit; ?>

  <?php require_once get_template_directory() .  '/components/common/footer.php'; ?> 
</main>

<?php require_once get_template_directory() .  '/partials/footer-scripts.php'; ?>
</body>
</html>