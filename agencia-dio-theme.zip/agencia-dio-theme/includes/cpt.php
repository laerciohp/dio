<?php
  if ( ! function_exists( 'add_action' ) ) exit;
  
  function register_cpt() {

    register_post_type(
      'portfolio',
      array(
        'labels' => array(
          'name'         => 'Portfólio',
          'add_new_item' => 'Novo',
          'menu_name'    => 'Portfólio',
          'not_found'    => 'not found',
        ),
        'public'              => true,
        'menu_icon'           => 'dashicons-portfolio',
        'publicly_queryable'  => true,
        'menu_position'       => 5,
        'capability_type'     => 'post',
        'hierarchical'        => true,
        'supports'            => array( 'title', 'editor'),
        'rewrite'             => array( 'slug' => 'portfolio-dio' ),
        'show_in_rest'        => true,
        'has_archive'         => true,
        'query_var'           => true,
      )
    );
  }

  function register_tax() {

    register_taxonomy(
      'portfolio_category',
      'portfolio',
      array (
        'labels' => array (
        'name' => 'Categorias - Portfólio',
      ),
      'public' => true,
      'hierarchical' => true,
      'show_admin_column' => true,
      'show_in_rest_api' => true,
      'show_in_rest' => [
        'schema' => [
            'type' => 'string',
            'format' => 'url',
            'context' => ['view'],
            'readonly' => true,
       ]
      ],
      'rewrite' => array( 'slug' => 'portfolio-dio-categoria' ),
      )
    );
  }
  
  add_action( 'init', 'register_cpt' );
  add_action( 'init', 'register_tax' );