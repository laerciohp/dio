<?php
  if ( ! function_exists( 'add_action' ) ) exit;
  
  function disable_custom_rest_endpoints( $endpoints ) {
    $routes = array( '/wp/v2/users', '/wp/v2/users/(?P<id>[\d]+)' );

    foreach ( $routes as $route ) {
      if ( empty( $endpoints[ $route ] ) ) {
        continue;
      }

      foreach ( $endpoints[ $route ] as $i => $handlers ) {
        if ( is_array( $handlers ) && isset( $handlers['methods'] ) &&
        'GET' === $handlers['methods'] ) {
          unset( $endpoints[ $route ][ $i ] );
        }
      }
    }

    return $endpoints;
  }

  add_filter( 'rest_endpoints', 'disable_custom_rest_endpoints' );

  // add_filter( 'rest_authentication_errors', function( $result ) {
  //   if ( ! empty( $result ) ) {
  //     return $result;
  //   }
    
  //   if ( ! is_user_logged_in() ) {
  //     return new WP_Error( 'rest_not_logged_in', 'You are not currently logged in.', array( 'status' => 401 ) );
  //   }

  //   return $result;
  // });

  //
  // file xmlrpc.php
  //
  add_filter( 'xmlrpc_enabled', '__return_false' );

  if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST )
  exit;

  function disable_x_pingback( $headers ) {
    unset( $headers['X-Pingback'] );  
    return $headers;
  }

  add_filter( 'wp_headers', 'disable_x_pingback' );
  
  remove_action( 'wp_head', 'rsd_link' );