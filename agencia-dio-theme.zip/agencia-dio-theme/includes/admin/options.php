<?php
  if ( ! function_exists( 'add_action' ) ) exit;

  if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
      'page_title' 	=> 'Informações Gerais - Configuração',
      'menu_title'	=> 'Informações Gerais',
      'menu_slug' 	=> 'theme-general-settings',
      'capability'	=> 'edit_posts',
      'redirect'		=> false
    ));

    // acf_add_options_sub_page(array(
    //   'page_title'    => 'Menu Principal',
    //   'menu_title'    => 'Menu Principal',
    //   'parent_slug'   => 'theme-general-settings',
    // ));
  }