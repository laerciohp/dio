<?php if ( ! function_exists( 'add_action' ) ) exit; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <?php require_once  get_template_directory() . '/partials/header-meta.php'; ?>
  <?php wp_head(); ?>
</head>
<body>
  <main class="Main">
  <?php require_once  get_template_directory() . '/components/common/header.php'; ?>